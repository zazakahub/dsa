
//Section 2.1: Array-Based Stack Implementation
//Hamza Ka code
#include <iostream>
#include <string>
using namespace std;


class ArrayStack {
private:
    int arr[10];
    int top;

public:
    ArrayStack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == 9;
    }

    void push(int val) {
        if (isFull()) {
            cout << "Stack Overflow! Cannot push " << val << ". Stack is full.\n";
            return;
        }
        arr[++top] = val;
    }

    int pop() {
        if (isEmpty()) {
            cout << "Stack Underflow! Cannot pop. Stack is empty.\n";
            return -1;
        }
        return arr[top--];
    }

    int peek() {
        if (isEmpty()) {
            cout << "Stack is empty. Nothing to peek.\n";
            return -1;
        }
        return arr[top];
    }

    void display() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        for (int i = top; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << "\n";
    }
};
//Section 2.2: Linked List-Based Stack Implementation
//S2025332017 ka code hai
struct Node {
    int data;
    Node* next;
};

class LinkedListStack {
private:
    Node* top;

public:
    LinkedListStack() {
        top = nullptr;
    }

    bool isEmpty() {
        return top == nullptr;
    }

    void push(int val) {
        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            cout << "Cannot pop. Stack is empty.\n";
            return -1;
        }
        Node* temp = top;
        int poppedValue = temp->data;
        top = top->next;
        delete temp;
        return poppedValue;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Stack is empty. Nothing to peek.\n";
            return -1;
        }
        return top->data;
    }

    void display() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        Node* current = top;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << "\n";
    }

    ~LinkedListStack() {
        while (!isEmpty()) {
            pop();
        }
    }
};
//Section 2.3: Demonstration in main()
int main() {
    cout << "        ARRAY STACK DEMONSTRATION       \n";
    ArrayStack arrStack;

    cout << "Pushing 5 values (10, 20, 30, 40, 50)...\n";
    arrStack.push(10);
    arrStack.push(20);
    arrStack.push(30);
    arrStack.push(40);
    arrStack.push(50);

    cout << "Array Stack contents (top to bottom): ";
    arrStack.display();

    cout << "\nPeeking top element: " << arrStack.peek() << "\n";

    cout << "\nPopping 2 values...\n";
    cout << "Popped: " << arrStack.pop() << "\n";
    cout << "Popped: " << arrStack.pop() << "\n";

    cout << "Array Stack contents after pops: ";
    arrStack.display();

    cout << "\nEmptying stack to trigger underflow...\n";
    arrStack.pop();
    arrStack.pop();
    arrStack.pop();
    cout << "Attempting extra pop: ";
    arrStack.pop();

    cout << "     LINKED LIST STACK DEMONSTRATION    \n";
    LinkedListStack listStack;

    cout << "Pushing 5 values (100, 200, 300, 400, 500)...\n";
    listStack.push(100);
    listStack.push(200);
    listStack.push(300);
    listStack.push(400);
    listStack.push(500);

    cout << "Linked List Stack contents (top to bottom): ";
    listStack.display();

    cout << "\nPeeking top element: " << listStack.peek() << "\n";

    cout << "\nPopping 2 values\n";
    cout << "Popped: " << listStack.pop() << "\n";
    cout << "Popped: " << listStack.pop() << "\n";

    cout << "Linked List Stack contents after pops: ";
    listStack.display();

    cout << "\nEmptying stack to trigger underflow\n";
    listStack.pop();
    listStack.pop();
    listStack.pop();
    cout << "Attempting extra pop: ";
    listStack.pop();
    cout << "Thank you for executing Zaza's code! ";
    return 0;
}

//Hamza Ka Question 3
/*     <--------- delete to try Q3

struct CharNode {
    char data;
    CharNode* next;
};

class CustomCharStack {
private:
    CharNode* top;

public:
    CustomCharStack() {
        top = nullptr;
    }

    bool isEmpty() {
        return top == nullptr;
    }

    void push(char val) {
        CharNode* newNode = new CharNode();
        newNode->data = val;
        newNode->next = top;
        top = newNode;
    }

    char pop() {
        if (isEmpty()) {
            return '\0';
        }
        CharNode* temp = top;
        char poppedValue = temp->data;
        top = top->next;
        delete temp;
        return poppedValue;
    }

    char peek() {
        if (isEmpty()) {
            return '\0';
        }
        return top->data;
    }

};


bool isBalanced(string expr) {
    CustomCharStack s;

    for (int i = 0; i < expr.length(); i++) {
        char ch = expr[i];

        // Push opening brackets onto our custom stack
        if (ch == '(' || ch == '{' || ch == '[') {
            s.push(ch);
        }
        // Handle closing brackets
        else if (ch == ')' || ch == '}' || ch == ']') {
            if (s.isEmpty()) {
                return false; // Underflow case
            }

            char topChar = s.peek();

            // Check for valid matching pairs
            if ((ch == ')' && topChar == '(') ||
                (ch == '}' && topChar == '{') ||
                (ch == ']' && topChar == '[')) {
                s.pop();
            } else {
                return false; // Mismatched brackets
            }
        }
    }

    return s.isEmpty();
}
int main() {
    string test1 = "(a + [b * {c + d}])";
    string test2 = "{a + (b - [c]}";

    cout << "Testing: \"" << test1 << "\"\n";
    cout << "Result: " << (isBalanced(test1) ? "balanced" : "not balanced") << "\n\n";

    cout << "Testing: \"" << test2 << "\"\n";
    cout << "Result: " << (isBalanced(test2) ? "balanced" : "not balanced") << "\n";

    return 0;
}
*/ // <--------- delete to try Q3
/*
 * STACK-BASED BALANCED BRACKET LOGIC:
 * 1. We instantiate our custom Char-based stack to track opening symbols.
 * 2. We scan the expression string from left to right.
 * 3. Any opening bracket encountered ('(', '{', '[') is immediately pushed onto the stack.
 * 4. When a closing bracket arrives (')', '}', ']'):
 * - We fail early if the stack is empty (this implies an orphan closing bracket).
 * - We peek at the top element. If it pairs correctly with our current character,
 * we pop it and keep evaluating. Otherwise, it's a mismatch, so we return false.
 * 5. Finally, if the stack is perfectly empty after the loop, all brackets matched up correctly.
 */





/* <--------------- delete to try  Q5


//Section 5.1: Linked List-Based Queue Implementation
//hamza ka code
struct Node {
    int data;
    Node* next;
};

class LinkedListQueue {
private:
    Node* frontPtr;
    Node* rearPtr;

public:
    LinkedListQueue() {
        frontPtr = nullptr;
        rearPtr = nullptr;
    }

    bool isEmpty() {
        return frontPtr == nullptr;
    }

    void enqueue(int val) {
        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = nullptr;

        if (isEmpty()) {
            frontPtr = newNode;
            rearPtr = newNode;
            return;
        }

        rearPtr->next = newNode;
        rearPtr = newNode;
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Cannot dequeue. Queue is empty.\n";
            return -1;
        }

        Node* temp = frontPtr;
        int dequeuedValue = temp->data;
        frontPtr = frontPtr->next;

        if (frontPtr == nullptr) {
            rearPtr = nullptr;
        }

        delete temp;
        return dequeuedValue;
    }

    int front() {
        if (isEmpty()) {
            cout << "Queue is empty. No front element.\n";
            return -1;
        }
        return frontPtr->data;
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is empty.\n";
            return;
        }
        Node* current = frontPtr;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << "\n";
    }

};
//Section 5.2: Circular Queue Implementation (Fixed Size 6)
class CircularQueue {
private:
    int arr[6];
    int frontPtr;
    int rearPtr;
    int capacity;
    int currentSize;

public:
    CircularQueue() {
        frontPtr = 0;
        rearPtr = -1;
        capacity = 6;
        currentSize = 0;
    }

    bool isEmpty() {
        return currentSize == 0;
    }

    bool isFull() {
        return currentSize == capacity;
    }

    void enqueue(int val) {
        if (isFull()) {
            cout << "Cannot enqueue " << val << ". Queue is full.\n";
            return;
        }

        rearPtr = (rearPtr + 1) % capacity;
        arr[rearPtr] = val;
        currentSize++;
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Cannot dequeue. Queue is empty.\n";
            return -1;
        }
        int dequeuedValue = arr[frontPtr];
        frontPtr = (frontPtr + 1) % capacity;
        currentSize--;
        return dequeuedValue;
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is empty.\n";
            return;
        }

        int index = frontPtr;
        for (int i = 0; i < currentSize; i++) {
            cout << arr[index] << " ";
            index = (index + 1) % capacity;
        }
        cout << "\n";
    }
};

//Section 5.3: Demonstration in main()
//Hamza s2025332017
int main() {
    cout << "     LINKED LIST QUEUE DEMONSTRATION     \n";
    LinkedListQueue llQueue;

    cout << "Enqueueing 5 values (10, 20, 30, 40, 50)\n";
    llQueue.enqueue(10);
    llQueue.enqueue(20);
    llQueue.enqueue(30);
    llQueue.enqueue(40);
    llQueue.enqueue(50);

    cout << "Linked List Queue contents: ";
    llQueue.display();

    cout << "\nDequeueing 2 values...\n";
    cout << "Dequeued: " << llQueue.dequeue() << "\n";
    cout << "Dequeued: " << llQueue.dequeue() << "\n";

    cout << "Linked List Queue contents after dequeues: ";
    //cannot copy code :p
    llQueue.display();

    cout << "       CIRCULAR QUEUE DEMONSTRATION     \n";
    CircularQueue circQueue;

    cout << "Filling circular queue to capacity\n";
    circQueue.enqueue(1);
    circQueue.enqueue(2);
    circQueue.enqueue(3);
    circQueue.enqueue(4);
    circQueue.enqueue(5);
    circQueue.enqueue(6);

    cout << "Circular Queue contents: ";
    circQueue.display();

    cout << "\nAttempting one more enqueue to trigger overflow:\n";
    circQueue.enqueue(7);

    cout << "\nDequeueing 2 values to create space at the beginning\n";
    cout << "Dequeued: " << circQueue.dequeue() << "\n";
    cout << "Dequeued: " << circQueue.dequeue() << "\n";

    cout << "Circular Queue contents after dequeues: ";
    circQueue.display();

    cout << "\nEnqueueing 2 new values to demonstrate wrap-around\n";
    circQueue.enqueue(8);
    circQueue.enqueue(9);

    cout << "Final Circular Queue contents (front to rear): ";
    circQueue.display();
    cout <<"Zaza Ka Q5\n";

    return 0;
}



*/ //<-------delete to try Q5


/* // <---------- delete to try Q6


//Section 6: Postfix Expression Evaluation
struct IntNode {
    int data;
    IntNode* next;
};

class CustomIntStack {
private:
    IntNode* top;

public:
    CustomIntStack() {
        top = nullptr;
    }

    bool isEmpty() {
        return top == nullptr;
    }

    void push(int val) {
        IntNode* newNode = new IntNode();
        newNode->data = val;
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            return 0;
        }
        IntNode* temp = top;
        int poppedValue = temp->data;
        top = top->next;
        delete temp;
        return poppedValue;
    }

    ~CustomIntStack() {
        while (!isEmpty()) {
            pop();
        }
    }
};


int evaluatePostfix(string expr) {
    CustomIntStack s;

    for (int i = 0; i < expr.length(); i++) {
        char ch = expr[i];

        // If the character is a digit, convert to int and push to stack
        if (ch >= '0' && ch <= '9') {
            s.push(ch - '0');
        }
        // If it's an operator, pop two elements and evaluate
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            int op2 = s.pop();
            int op1 = s.pop();

            int res = 0;
            switch (ch) {
                case '+':
                    res = op1 + op2;
                    break;
                case '-':
                    res = op1 - op2;
                    break;
                case '*':
                    res = op1 * op2;
                    break;
                case '/':
                    if (op2 == 0) {
                        cout << "Runtime Error: Division by zero encountered!\n";
                        return -1;
                    }
                    res = op1 / op2;
                    break;
            }
            s.push(res);
        }
    }

    return s.pop();
}
int main() {
   string t1 = "23+";
   string t2 = "53*2+";
   string t3 = "842-*";
   string t4 = "40/";

    cout << "Testing Postfix: \"" << t1 << "\" -> Expected: 5 | Got: " << evaluatePostfix(t1) << "\n";
    cout << "Testing Postfix: \"" << t2 << "\" -> Expected: 17 | Got: " << evaluatePostfix(t2) << "\n";
    cout << "Testing Postfix: \"" << t3 << "\" -> Expected: 16 | Got: " << evaluatePostfix(t3) << "\n\n";

    cout << "Testing Division-by-Zero: \"" << t4 << "\"\n";
    cout << "Returned Value: " << evaluatePostfix(t4) << "\n";
    cout << "Zaza ka Q6\n";
    return 0;
}

*/ // <------- DEL FOR q6


/*
 * STACK-BASED POSTFIX EVALUATION LOGIC:
 * 1. Read the postfix expression string character by character from left to right.
 * 2. If the character is a single-digit integer operand ('0' to '9'), convert it
 * from its ASCII character value to its actual integer value (ch - '0') and push it onto the stack.
 * 3. If the character is an operator (+, -, *, /):
 * - Pop the top element from the stack. This represents the second operand (operand2).
 * - Pop the next top element from the stack. This represents the first operand (operand1).
 * - Apply the operator on the two operands (operand1 operator operand2).
 * - Critical edge case check: If the operator is '/' and operand2 is 0, print a
 * "Division by Zero" error and return -1 immediately.
 * - Push the evaluated result back onto the stack.
 * 4. After scanning the entire string, the final remaining element on the stack is the total result.
 */

